import {
  router,
  json,
  error,
  requireAuth,
  db,
  storage,
  auth,
  increment,
} from '@appdeploy/sdk';
import type { RouterContext } from '@appdeploy/sdk';

// Fixed admin allow-list: server-side only, seeded once into the settings table. No API can change it.
const ADMIN_EMAILS = [
  'amp260115@gmail.com',
  'mittensnm2@gmail.com',
];

const SEED = [
  'Amigurumi|Panda|300|A sleepy little panda who loves cuddles.',
  'Amigurumi|Frog|150|A hoppy green friend ready for adventures.',
  'Amigurumi|Bear|300|A soft teddy that hugs back.',
  'Amigurumi|Polar Bear|300|A fluffy snow buddy for cozy days.',
  'Amigurumi|Tortoise|250|Slow and steady, extra cute.',
  'Amigurumi|Chicken|250|A cheerful little chick with a big smile.',
  'Amigurumi|Whale|150|A tiny whale full of sea-sized love.',
  'Amigurumi|Strawberry|150|A berry sweet pal made of yarn.',
  'Amigurumi|Mochi Cat|200|A squishy mochi kitty that purrs in yarn.',
  'Tea Coasters|Rose Bouquet Coasters (pack of 2)|500|Two blooming roses for your cup to rest on.',
  'Tea Coasters|Lemon Coasters (pack of 4)|400|Zesty lemon slices for sunny tea time.',
  'Tea Coasters|Bear Coasters (pack of 4)|400|Four beary cute spots for your mugs.','Bag Charms|Moon and Star|70|A dreamy night sky to dangle on your bag.',
  'Bag Charms|Cat Pop-It Fidget|90|A kitty you can squish and pop.',
  'Bag Charms|Cookie and Bear|100|A bear snuggling a yummy cookie.',
  'Bag Charms|Ribbon|70|A dainty bow to dress up your bag.',
  'Bag Charms|Lily of the Valley|90|Little white bells for a spring-y touch.',
  'Bag Charms|Lip Balm Holder|80|Keeps your lip balm close and cute.',
  'Bag Charms|Cherry Pair Charm|80|Two cherries, twice the cheer.',
  'Pouches|Drawstring Pouch|400|A snug little pouch for your treasures.',
  'Pouches|Tulip Pouch|450|A tulip-shaped pouch that blooms with charm.',
];

const sc = (v: unknown, n = 200) =>
  String(v ?? '')
    .trim()
    .slice(0, n);
const CATS = ['Amigurumi', 'Tea Coasters', 'Bag Charms', 'Pouches'];
const LOW = [
  'Awaiting payment verification',
  'Pending',
  'Approved',
  'Shipped',
  'Delivered',
  'Cancelled',
];

let ready = false;
async function seed() {
  if (ready) return;
  const [s] = await db.get<any>('settings', ['seeded'], { consistent: true });
  if (!s) {
    await db.tx.add(
      'products',
      SEED.map((r, i) => {
        const [category, name, price, description] = r.split('|');
        return {
          id: 'p' + (i + 1),
          name,
          category,
          price: Number(price),
          description,
          stock: 5,
          hidden: false,
          imagePath: null,
          soldCount: 0,
          ratingSum: 0,
          ratingCount: 0,
        };
      })
    );
    await db.tx.add('settings', [
      { id: 'config', adminEmails: ADMIN_EMAILS },
      { id: 'seeded', at: Date.now() },
    ]);
  }    const [rm] = await db.get<any>('settings', ['rm_peach']);
    if (!rm) {
        const all = await allProducts();
        const ids = all.filter((p) => String(p.name).startsWith('Peach Coasters')).map((p) => p.id);
        if (ids.length) await db.delete('products', ids);
        await db.tx.add('settings', [{ id: 'rm_peach', at: Date.now() }]);
    }
    const [rm2] = await db.get<any>('settings', ['rm_mig2']);
    if (!rm2) {
        const all2 = await allProducts();
        const gone = ['Frog', 'Cookie and Bear', 'Bear Coasters (pack of 4)'];
        const ids2 = all2.filter((p) => gone.includes(String(p.name))).map((p) => p.id);
        if (ids2.length) await db.delete('products', ids2);
        await db.tx.add('settings', [{ id: 'rm_mig2', at: Date.now() }]);
    }
    const [am] = await db.get<any>('settings', ['adm_mig1']);
    if (!am) {
        await db.tx.update('settings', [{ id: 'config', record: { adminEmails: ['amp260115@gmail.com', 'admin2@example.com', 'admin3@example.com'] } }]);
        await db.tx.add('settings', [{ id: 'adm_mig1', at: Date.now() }]);
    }
    const [am2] = await db.get<any>('settings', ['adm_mig2']);
    if (!am2) {
        await db.tx.update('settings', [{ id: 'config', record: { adminEmails: ['amp260115@gmail.com', 'mittensnm2@gmail.com'] } }]);
        await db.tx.add('settings', [{ id: 'adm_mig2', at: Date.now() }]);
    }
    ready = true;
}

async function isAdmin(email?: string) {
  if (!email) return false;
  const [c] = await db.get<any>('settings', ['config']);
  const list: string[] = (c?.adminEmails || [])
    .slice(0, 3)
    .map((e: string) => e.toLowerCase());
  return list.includes(email.toLowerCase());
}

const adminOnly = async (ctx: RouterContext) => {
  await seed();
  if (!(await isAdmin(ctx.user?.email))) return error('Access denied', 403);
};

async function getMe(ctx: RouterContext) {
  await seed();
  const u = ctx.user!;
  const role = (await isAdmin(u.email)) ? 'admin' : 'customer';
  const [ex] = await db.get<any>('users', [u.userId]);
  if (ex && ex.role === role) return { ...ex, id: u.userId };
  const rec = {
    name: ex?.name || u.name || '',
    email: u.email || '',
    phone: ex?.phone || '',
    role,
    addresses: ex?.addresses || [],
    cart: ex?.cart || [],
    viewed: ex?.viewed || [],
    orderIds: ex?.orderIds || [],
  };
  await db.tx.update('users', [{ id: u.userId, record: rec }]);
  return { ...rec, id: u.userId };
}

async function withImages(ps: any[]) {
  const paths = ps.filter(p => p.imagePath).map(p => p.imagePath);
  if (!paths.length) return ps.map(p => ({ ...p, imageUrl: null }));
  const urls = await storage.url(paths);
  const m = new Map(urls.map(x => [x.path, x.url]));
  return ps.map(p => ({
    ...p,
    imageUrl: p.imagePath ? m.get(p.imagePath) || null : null,
  }));
}

async function allProducts() {
  const r = await db.list<any>('products', { limit: 200 });
  return r.items;
}

async function ordersByIds(ids: string[]) {
  if (!ids.length) return [];
  const os = await db.get<any>('orders', ids);
  return os
    .map((o, i) => (o ? { ...o, id: ids[i] } : null))
    .filter(o => o) as any[];
}

function cleanProduct(b: any) {
  const price = Number(b.price);
  const stock = Math.floor(Number(b.stock));
  if (
    !sc(b.name) ||
    !(price >= 0) ||
    !(stock >= 0) ||
    !CATS.includes(b.category)
  )
    return null;
  return {
    name: sc(b.name, 80),
    description: sc(b.description, 300),
    price,
    stock,
    category: b.category,
    hidden: !!b.hidden,
  };
}

export const handler = router({
  'GET /api/products': [
    async () => {
      await seed();
      const ps = (await allProducts()).filter(p => !p.hidden);
      return json(await withImages(ps));
    },
  ],

  'GET /api/recommended': [
    async ctx => {
      await seed();
      const ps = (await allProducts()).filter(p => !p.hidden && p.stock > 0);
      const u = await auth.getUser(ctx.event);
      const cats = new Set<string>();
      if (u) {
        const [me] = await db.get<any>('users', [u.userId]);
        const byId = new Map(ps.map(p => [p.id, p.category]));
        (me?.viewed || []).forEach(
          (id: string) => byId.get(id) && cats.add(byId.get(id) as string)
        );
        const os = await ordersByIds((me?.orderIds || []).slice(-20));
        os.forEach(o =>
          o.items.forEach(
            (i: any) =>
              byId.get(i.productId) && cats.add(byId.get(i.productId) as string)
          )
        );
      }
      const score = (p: any) =>
        (cats.has(p.category) ? 3 : 0) +
        (p.ratingCount ? p.ratingSum / p.ratingCount : 0) +
        p.soldCount * 0.2;
      const top = [...ps]
        .sort((a, b) => (u ? score(b) - score(a) : b.soldCount - a.soldCount))
        .slice(0, 8);
      return json({ personal: !!u, items: await withImages(top) });
    },
  ],

  'GET /api/qr': [
    async () => {
      await seed();
      const [q] = await db.get<any>('settings', ['qr']);
      if (!q?.path) return json({ url: null });
      const [x] = await storage.url([q.path]);
      return json({ url: x?.url || null });
    },
  ],

  'GET /api/me': [
    requireAuth(),
    async ctx => {
      const user = await getMe(ctx);
      return json({ user, isAdmin: user.role === 'admin' });
    },
  ],

  'PUT /api/me': [
    requireAuth(),
    async ctx => {
      const me = await getMe(ctx);
      const b = (ctx.body || {}) as any;
      const rec: Record<string, unknown> = {};
      if (b.name !== undefined) rec.name = sc(b.name, 80);
      if (b.phone !== undefined) rec.phone = sc(b.phone, 20);
      if (Array.isArray(b.addresses))
        rec.addresses = b.addresses
          .slice(0, 5)
          .map((a: any) => ({
            name: sc(a.name, 80),
            phone: sc(a.phone, 20),
            street: sc(a.street, 200),
            city: sc(a.city, 80),
            state: sc(a.state, 80),
            pin: sc(a.pin, 6),
          }));
      if (Array.isArray(b.cart))
        rec.cart = b.cart
          .slice(0, 30)
          .map((c: any) => ({
            productId: sc(c.productId, 40),
            qty: Math.min(99, Math.max(1, Math.floor(Number(c.qty)) || 1)),
          }));
      if (Object.keys(rec).length)
        await db.tx.update('users', [{ id: me.id, record: rec }], {
          patch: true,
        });
      return json({ ok: true });
    },
  ],

  'POST /api/view': [
    requireAuth(),
    async ctx => {
      const me = await getMe(ctx);
      const id = sc((ctx.body as any)?.productId, 40);
      const viewed = [
        id,
        ...(me.viewed || []).filter((v: string) => v !== id),
      ].slice(0, 20);
      await db.tx.update('users', [{ id: me.id, record: { viewed } }], {
        patch: true,
      });
      return json({ ok: true });
    },
  ],

  'POST /api/orders': [
    requireAuth(),
    async ctx => {
      const me = await getMe(ctx);
      const b = (ctx.body || {}) as any;
      const a = b.address || {};
      const address = {
        name: sc(a.name, 80),
        phone: sc(a.phone, 20),
        street: sc(a.street, 200),
        city: sc(a.city, 80),
        state: sc(a.state, 80),
        pin: sc(a.pin, 6),
      };
      if (Object.values(address).some(v => !v) || !/^\d{6}$/.test(address.pin))
        return error(
          'Please fill the full delivery address with a 6-digit PIN code',
          400
        );
      const method = b.method === 'COD' ? 'COD' : b.method === 'QR' ? 'QR' : '';
      if (!method) return error('Choose a payment method', 400);
      const ref = sc(b.paymentRef, 80);
      if (method === 'QR' && !ref)
        return error('Enter your UPI/transaction reference', 400);
      const qtyById = new Map<string, number>();
      (Array.isArray(b.items) ? b.items : []).slice(0, 30).forEach((i: any) => {
        const q = Math.floor(Number(i.qty));
        if (q >= 1 && q <= 99)
          qtyById.set(
            sc(i.productId, 40),
            (qtyById.get(sc(i.productId, 40)) || 0) + q
          );
      });
      const ids = [...qtyById.keys()];
      if (!ids.length || ids.length > 30)
        return error('Your cart is empty', 400);
      const prods = await db.get<any>('products', ids, { consistent: true });
      const items: any[] = [];
      for (let k = 0; k < ids.length; k++) {
        const p = prods[k];
        const qty = qtyById.get(ids[k]) as number;
        if (!p || p.hidden)
          return error('An item in your cart is no longer available', 409);
        if (p.stock < qty)
          return error('Only ' + p.stock + ' left of ' + p.name, 409);
        items.push({
          productId: ids[k],
          name: p.name,
          price: p.price,
          qty,
          stock: p.stock,
        });
      }
      const total = items.reduce((s, i) => s + i.price * i.qty, 0);
      const orderId =
        'o' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      const number = 'MIT-' + orderId.slice(-6).toUpperCase();
      const status =
        method === 'QR' ? 'Awaiting payment verification' : 'Pending';
      const order = {
        userId: me.id,
        userName: me.name || address.name,
        userEmail: me.email,
        items: items.map(({ stock, ...i }) => i),
        total,
        status,
        paymentMethod: method,
        address,
        paymentRef: method === 'QR' ? ref : '',
        paymentConfirmed: false,
        number,
        createdAt: Date.now(),
      };
      const addrs = me.addresses || [];
      const saved =
        b.saveAddress &&
        addrs.length < 5 &&
        !addrs.some(
          (x: any) => x.street === address.street && x.pin === address.pin
        )
          ? [...addrs, address]
          : addrs;
      const ops: any[] = items.map(i =>
        db.tx.update(
          'products',
          [
            {
              id: i.productId,
              record: { stock: increment(-i.qty), soldCount: increment(i.qty) },
              if: { stock: i.stock },
            },
          ],
          { patch: true }
        )
      );
      ops.push(db.tx.add('orders', [{ id: orderId, ...order }]));
      ops.push(
        db.tx.add(
          'order_items',
          order.items.map((i: any, n: number) => ({
            id: orderId + '_' + n,
            orderId,
            ...i,
          }))
        )
      );
      ops.push(
        db.tx.update(
          'users',
          [
            {
              id: me.id,
              record: {
                cart: [],
                addresses: saved,
                orderIds: [...(me.orderIds || []), orderId].slice(-100),
              },
            },
          ],
          { patch: true }
        )
      );
      try {
        await db.transact(ops);
      } catch (e) {
        console.error('order failed', e);
        return error(
          'Stock just changed. Please refresh your cart and try again.',
          409
        );
      }
      return json({ id: orderId, ...order });
    },
  ],

  'GET /api/orders': [
    requireAuth(),
    async ctx => {
      const me = await getMe(ctx);
      const os = await ordersByIds((me.orderIds || []).slice(-50));
      return json(os.reverse());
    },
  ],

  'GET /api/reviews': [
    async () => {
      const r = await db.list<any>('reviews', { limit: 100 });
      return json(
        r.items.sort((a, b) => b.createdAt - a.createdAt).slice(0, 40)
      );
    },
  ],

  'GET /api/products/:id/reviews': [
    async ctx => {
      const pid = ctx.params.id;
      const r = await db.list<any>('reviews', {
        limit: 200,
        filter: { productId: pid },
      });
      const reviews = r.items.sort((a, b) => b.createdAt - a.createdAt);
      let canReview = false;
      const u = await auth.getUser(ctx.event);
      if (u && !reviews.some(x => x.userId === u.userId)) {
        const [me] = await db.get<any>('users', [u.userId]);
        const os = await ordersByIds((me?.orderIds || []).slice(-100));
        canReview = os.some(
          o =>
            o.status === 'Delivered' &&
            o.items.some((i: any) => i.productId === pid)
        );
      }
      return json({ reviews, canReview });
    },
  ],

  'POST /api/reviews': [
    requireAuth(),
    async ctx => {
      const me = await getMe(ctx);
      const b = (ctx.body || {}) as any;
      const pid = sc(b.productId, 40);
      const rating = Math.floor(Number(b.rating));
      if (!(rating >= 1 && rating <= 5))
        return error('Rating must be 1 to 5', 400);
      const os = await ordersByIds((me.orderIds || []).slice(-100));
      if (
        !os.some(
          o =>
            o.status === 'Delivered' &&
            o.items.some((i: any) => i.productId === pid)
        )
      )
        return error(
          'Only customers who received this product can review it',
          403
        );
      const [p] = await db.get<any>('products', [pid]);
      if (!p) return error('Product not found', 404);
      try {
        await db.transact([
          db.tx.add('reviews', [
            {
              id: me.id + '_' + pid,
              userId: me.id,
              userName: (me.name || 'Customer').split(' ')[0],
              productId: pid,
              productName: p.name,
              rating,
              comment: sc(b.comment, 500),
              createdAt: Date.now(),
            },
          ]),
          db.tx.update(
            'products',
            [
              {
                id: pid,
                record: {
                  ratingSum: increment(rating),
                  ratingCount: increment(1),
                },
              },
            ],
            { patch: true }
          ),
        ]);
      } catch (e) {
        return error('You have already reviewed this product', 409);
      }
      return json({ ok: true });
    },
  ],

  'GET /api/admin/orders': [
    requireAuth(),
    adminOnly,
    async () => {
      const r = await db.list<any>('orders', { limit: 200 });
      return json(r.items.sort((a, b) => b.createdAt - a.createdAt));
    },
  ],

  'POST /api/admin/orders/:id/action': [
    requireAuth(),
    adminOnly,
    async ctx => {
      const id = ctx.params.id;
      const action = sc((ctx.body as any)?.action, 20);
      const [o] = await db.get<any>('orders', [id], { consistent: true });
      if (!o) return error('Order not found', 404);
      if (action === 'cancel') {
        if (o.status === 'Cancelled' || o.status === 'Delivered')
          return error('This order cannot be cancelled', 400);
        const prods = await db.get<any>(
          'products',
          o.items.map((i: any) => i.productId)
        );
        const ops: any[] = [
          db.tx.update(
            'orders',
            [{ id, record: { status: 'Cancelled' }, if: { status: o.status } }],
            { patch: true }
          ),
        ];
        o.items.forEach((i: any, k: number) => {
          if (prods[k])
            ops.push(
              db.tx.update(
                'products',
                [
                  {
                    id: i.productId,
                    record: {
                      stock: increment(i.qty),
                      soldCount: increment(-i.qty),
                    },
                  },
                ],
                { patch: true }
              )
            );
        });
        try {
          await db.transact(ops);
        } catch (e) {
          return error('Order changed, please refresh', 409);
        }
        return json({ ok: true });
      }
      if (o.status === 'Cancelled') return error('Order is cancelled', 400);
      const rec: Record<string, unknown> = {};
      if (action === 'approve') rec.status = 'Approved';
      else if (action === 'ship') rec.status = 'Shipped';
      else if (action === 'deliver') rec.status = 'Delivered';
      else if (action === 'confirm_payment') {
        if (o.paymentMethod !== 'QR')
          return error('Only QR payments need confirmation', 400);
        rec.paymentConfirmed = true;
        if (o.status === 'Awaiting payment verification')
          rec.status = 'Approved';
      } else return error('Unknown action', 400);
      await db.tx.update('orders', [{ id, record: rec }], { patch: true });
      return json({ ok: true });
    },
  ],

  'GET /api/admin/products': [
    requireAuth(),
    adminOnly,
    async () => json(await withImages(await allProducts())),
  ],

  'POST /api/admin/products': [
    requireAuth(),
    adminOnly,
    async ctx => {
      const rec = cleanProduct((ctx.body || {}) as any);
      if (!rec) return error('Invalid product details', 400);
      const id = 'p' + Date.now().toString(36);
      await db.tx.add('products', [
        {
          id,
          ...rec,
          imagePath: null,
          soldCount: 0,
          ratingSum: 0,
          ratingCount: 0,
        },
      ]);
      return json({ id });
    },
  ],

  'PUT /api/admin/products/:id': [
    requireAuth(),
    adminOnly,
    async ctx => {
      const rec = cleanProduct((ctx.body || {}) as any);
      if (!rec) return error('Invalid product details', 400);
      const [ok] = await db.tx.update(
        'products',
        [{ id: ctx.params.id, record: rec }],
        { patch: true }
      );
      return ok ? json({ ok: true }) : error('Product not found', 404);
    },
  ],

  'DELETE /api/admin/products/:id': [
    requireAuth(),
    adminOnly,
    async ctx => {
      const [p] = await db.get<any>('products', [ctx.params.id]);
      if (!p) return error('Product not found', 404);
      await db.delete('products', [ctx.params.id]);
      if (p.imagePath) await storage.delete([p.imagePath]);
      return json({ ok: true });
    },
  ],

  'POST /api/admin/image': [
    requireAuth(),
    adminOnly,
    async ctx => {
      const { target, data, type } = (ctx.body || {}) as any;
      if (
        !/^image\/(jpeg|png|webp)$/.test(String(type)) ||
        typeof data !== 'string' ||
        data.length > 4500000
      )
        return error('Invalid image (max about 3 MB)', 400);
      const ext = String(type).split('/')[1];
      if (target === 'qr') {
        const path = 'settings/payment-qr-' + Date.now() + '.' + ext;
        const [ok] = await storage.write([
          { path, content: data, contentType: type },
        ]);
        if (!ok) return error('Upload failed', 500);
        const [q] = await db.get<any>('settings', ['qr']);
        await db.tx.update('settings', [{ id: 'qr', record: { path } }]);
        if (q?.path) await storage.delete([q.path]);
        return json({ ok: true });
      }
      const [p] = await db.get<any>('products', [sc(target, 40)]);
      if (!p) return error('Product not found', 404);
      const path = 'products/' + sc(target, 40) + '-' + Date.now() + '.' + ext;
      const [ok] = await storage.write([
        { path, content: data, contentType: type },
      ]);
      if (!ok) return error('Upload failed', 500);
      await db.tx.update(
        'products',
        [{ id: sc(target, 40), record: { imagePath: path, noPhoto: false } }],
        { patch: true }
      );
      if (p.imagePath) await storage.delete([p.imagePath]);
      return json({ ok: true });
    },
  ],

  'DELETE /api/admin/products/:id/image': [
    requireAuth(),
    adminOnly,
    async ctx => {
      const [p] = await db.get<any>('products', [ctx.params.id]);
      if (!p) return error('Product not found', 404);
      await db.tx.update(
        'products',
        [{ id: ctx.params.id, record: { imagePath: null, noPhoto: true } }],
        { patch: true }
      );
      if (p.imagePath) await storage.delete([p.imagePath]);
      return json({ ok: true });
    },
  ],

  'GET /api/_healthcheck': [
    async () => json({ message: 'Success', statuses: LOW.length }),
  ],
});
