import Mittens from './Mittens';

function App() {
  return <Mittens />;
}

export default App;
