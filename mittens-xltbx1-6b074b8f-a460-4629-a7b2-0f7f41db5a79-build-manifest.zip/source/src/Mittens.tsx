import { useEffect, useState } from 'react';
import { api, auth } from '@appdeploy/client';

const CATS = ['Amigurumi', 'Tea Coasters', 'Bag Charms', 'Pouches'];
const PHOTO: any = {
  'Mochi Cat': 'photo1',
  'Tulip Pouch': 'photo7',
  'Rose Bouquet Coasters (pack of 2)': ['photo8', 'photo9'],
  'Cherry Pair Charm': 'photo2',
  Ribbon: 'photo5',
  Chicken: 'photo6',
};
const EMO: any = {
  Amigurumi: '🧸',
  'Tea Coasters': '☕',
  'Bag Charms': '🎀',
  Pouches: '👝',
};
const BG = ['#FFD6E0', '#FFE8C7', '#E3D4FF', '#CDEFE0', '#FFF3B0', '#CFE8FF'];
const rs = (n: number) => '₹' + n;
const stars = (r: number) =>
  '★'.repeat(Math.round(r)) + '☆'.repeat(5 - Math.round(r));
const msg = (e: any) =>
  e?.response?.data?.error || e?.message || 'Something went wrong';
const go = (h: string) => {
  location.hash = h;
};

const toB64 = (f: File) =>
  new Promise<{ data: string; type: string }>(res => {
    const r = new FileReader();
    r.onload = () => {
      const im = new Image();
      im.onload = () => {
        const s = Math.min(1, 900 / Math.max(im.width, im.height));
        const c = document.createElement('canvas');
        c.width = Math.round(im.width * s);
        c.height = Math.round(im.height * s);
        c.getContext('2d')!.drawImage(im, 0, 0, c.width, c.height);
        res({
          data: c.toDataURL('image/jpeg', 0.9).split(',')[1],
          type: 'image/jpeg',
        });
      };
      im.src = r.result as string;
    };
    r.readAsDataURL(f);
  });

const FL: any = {
  name: 'Full name',
  phone: 'Phone number',
  street: 'Street address',
  city: 'City',
  state: 'State',
  pin: 'PIN code (6 digits)',
};
const photosOf = (n: string): string[] =>
  ([] as string[]).concat(PHOTO[n] || []);

function Img({ p, idx = 0 }: { p: any; idx?: number }) {
  const list = p.noPhoto ? [] : photosOf(p.name);
  const src =
    p.imageUrl || (list[idx] ? './resources/' + list[idx] + '.jpg' : '');
  if (src)
    return (
      <img
        src={src}
        alt={p.name}
        className="object-cover w-full h-full"
      />
    );
  const i = (p.name || '').length % BG.length;
  return (
    <div
      className="w-full h-full flex flex-col items-center justify-center text-5xl"
      style={{ background: BG[i] }}
    >
      <span>{EMO[p.category] || '🧶'}</span>
      <span className="text-xs mt-1 opacity-60">photo coming soon</span>
    </div>
  );
}

function Card({ p }: { p: any }) {
  return (
    <a
      href={'#/p/' + p.id}
      className="block bg-white rounded-3xl shadow-md overflow-hidden border-2 border-pink-100 no-underline text-inherit"
    >
      <div className="aspect-square">
        <Img p={p} />
      </div>
      <div className="p-3">
        <div className="font-bold text-sm">{p.name}</div>
        <div className="flex justify-between items-center">
          <span className="font-extrabold" style={{ color: '#ff6b8b' }}>
            {rs(p.price)}
          </span>
          {p.stock <= 0 && (
            <span className="text-xs text-gray-400">Sold out</span>
          )}
        </div>
      </div>
    </a>
  );
}

const Grid = ({ list }: { list: any[] }) => (
  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
    {list.map(p => (
      <Card key={p.id} p={p} />
    ))}
  </div>
);

function Login({ X }: { X: any }) {
  return (
    <div className="box text-center">
      <div className="text-4xl">🧶</div>
      <p>Please sign in to continue.</p>
      <button className="btn" onClick={X.signIn}>
        Sign in
      </button>
    </div>
  );
}

function Home({ X }: { X: any }) {
  const [cat, setCat] = useState('All');
  const [rec, setRec] = useState<any[]>([]);
  useEffect(() => {
    api
      .get('/api/recommended')
      .then(r => setRec(r.data.items.slice(0, 4)))
      .catch(() => {});
  }, [X.me]);
  const list = X.products.filter(
    (p: any) => cat === 'All' || p.category === cat
  );
  const feat = [...X.products]
    .sort((a: any, b: any) => b.soldCount - a.soldCount)
    .slice(0, 4);
  return (
    <div className="space-y-6">
      <div
        className="rounded-3xl p-8 text-center"
        style={{
          background: 'linear-gradient(135deg,#ffc2d1,#ffe8c7,#e3d4ff)',
        }}
      >
        <div className="text-5xl">🧶🧸🎀</div>
        <h1 className="text-3xl font-extrabold my-2">
          Handmade crochet, made with love
        </h1>
        <p>Tiny friends, cozy coasters, cute bag charms and pouches.</p>
        <a href="#/foryou" className="btn inline-block mt-3 no-underline">
          Recommended for you
        </a>
      </div>
      <section>
        <h2 className="text-xl font-extrabold mb-2">✨ Featured</h2>
        <Grid list={feat} />
      </section>
      <section>
        <h2 className="text-xl font-extrabold mb-2">Shop by category</h2>
        <div className="flex gap-2 flex-wrap mb-3">
          {['All', ...CATS].map(c => (
            <button
              key={c}
              className={c === cat ? 'btn' : 'btn2'}
              onClick={() => setCat(c)}
            >
              {c}
            </button>
          ))}
        </div>
        <Grid list={list} />
      </section>
      {rec.length > 0 && (
        <section>
          <h2 className="text-xl font-extrabold mb-2">
            💖 Recommended for You
          </h2>
          <Grid list={rec} />
        </section>
      )}
    </div>
  );
}

function ForYou({ X }: { X: any }) {
  const [d, setD] = useState<any>({ items: [], personal: false });
  useEffect(() => {
    api
      .get('/api/recommended')
      .then(r => setD(r.data))
      .catch(() => {});
  }, [X.me]);
  return (
    <div>
      <h1 className="text-2xl font-extrabold mb-1">💖 Recommended for You</h1>
      <p className="mb-3">
        {d.personal
          ? 'Picked from what you have viewed and bought, plus top-rated treats.'
          : 'Our best sellers. Sign in for picks made just for you.'}
      </p>
      <Grid list={d.items} />
    </div>
  );
}

function Product({ X, id }: { X: any; id: string }) {
  const p = X.products.find((x: any) => x.id === id);
  const [qty, setQty] = useState(1);
  const [pic, setPic] = useState(0);
  const [rv, setRv] = useState<any>({ reviews: [], canReview: false });
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const load = () =>
    api
      .get('/api/products/' + id + '/reviews')
      .then(r => setRv(r.data))
      .catch(() => {});
  useEffect(() => {
    load();
    if (X.me) api.post('/api/view', { productId: id }).catch(() => {});
  }, [id, X.me]);
  if (!p) return <div className="box">Product not found.</div>;
  const avg = p.ratingCount ? p.ratingSum / p.ratingCount : 0;
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <div className="rounded-3xl overflow-hidden aspect-square border-2 border-pink-100">
            <Img p={p} idx={pic} />
          </div>
          {!p.noPhoto && photosOf(p.name).length > 1 && (
            <div className="flex gap-2 mt-2">
              {photosOf(p.name).map((_: string, k: number) => (
                <button
                  key={k}
                  className={k === pic ? 'btn' : 'btn2'}
                  onClick={() => setPic(k)}
                >
                  {k === 0 ? 'Closed' : 'Open'}
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="box space-y-3">
          <h1 className="text-2xl font-extrabold">{p.name}</h1>
          <div style={{ color: '#f5a623' }}>
            {stars(avg)}{' '}
            <span className="text-sm text-gray-500">
              {p.ratingCount
                ? avg.toFixed(1) + ' (' + p.ratingCount + ')'
                : 'No reviews yet'}
            </span>
          </div>
          <p>{p.description}</p>
          <div className="text-2xl font-extrabold" style={{ color: '#ff6b8b' }}>
            {rs(p.price)}
          </div>
          <div>
            {p.stock > 0
              ? p.stock <= 2
                ? 'Only ' + p.stock + ' left!'
                : 'In stock'
              : 'Out of stock'}
          </div>
          {p.stock > 0 && (
            <div className="flex items-center gap-3">
              <button
                className="btn2"
                onClick={() => setQty(Math.max(1, qty - 1))}
              >
                -
              </button>
              <b>{qty}</b>
              <button
                className="btn2"
                onClick={() => setQty(Math.min(p.stock, qty + 1))}
              >
                +
              </button>
              <button className="btn" onClick={() => X.addToCart(p.id, qty)}>
                Add to cart
              </button>
            </div>
          )}
        </div>
      </div>
      <div className="box">
        <h2 className="font-extrabold mb-2">Reviews</h2>
        {rv.reviews.length === 0 && <p>No reviews yet.</p>}
        {rv.reviews.map((r: any) => (
          <div key={r.id} className="border-b py-2">
            <span style={{ color: '#f5a623' }}>{stars(r.rating)}</span>{' '}
            <b>{r.userName}</b>
            <div>{r.comment}</div>
          </div>
        ))}
        {rv.canReview && (
          <div className="mt-3 space-y-2">
            <select
              className="inp"
              value={rating}
              onChange={e => setRating(Number(e.target.value))}
            >
              {[5, 4, 3, 2, 1].map(n => (
                <option key={n} value={n}>
                  {n} stars
                </option>
              ))}
            </select>
            <textarea
              className="inp"
              placeholder="Write your review"
              value={comment}
              onChange={e => setComment(e.target.value)}
            />
            <button
              className="btn"
              onClick={() =>
                api
                  .post('/api/reviews', { productId: id, rating, comment })
                  .then(() => {
                    X.flash('Thanks for your review!');
                    load();
                    X.reloadProducts();
                  })
                  .catch((e: any) => X.flash(msg(e)))
              }
            >
              Post review
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function CartPage({ X }: { X: any }) {
  const items = X.cart
    .map((c: any) => ({
      ...c,
      p: X.products.find((p: any) => p.id === c.productId),
    }))
    .filter((i: any) => i.p);
  const total = items.reduce((s: number, i: any) => s + i.p.price * i.qty, 0);
  const set = (id: string, q: number) =>
    X.saveCart(
      X.cart
        .map((c: any) => (c.productId === id ? { ...c, qty: q } : c))
        .filter((c: any) => c.qty > 0)
    );
  if (!X.me) return <Login X={X} />;
  return (
    <div className="box space-y-3">
      <h1 className="text-2xl font-extrabold">🛒 Your cart</h1>
      {items.length === 0 && <p>Your cart is empty.</p>}
      {items.map((i: any) => (
        <div key={i.productId} className="flex items-center gap-3">
          <div className="w-16 h-16 rounded-2xl overflow-hidden">
            <Img p={i.p} />
          </div>
          <div className="flex-1">
            <b>{i.p.name}</b>
            <div>{rs(i.p.price)}</div>
          </div>
          <button className="btn2" onClick={() => set(i.productId, i.qty - 1)}>
            -
          </button>
          <b>{i.qty}</b>
          <button
            className="btn2"
            onClick={() => set(i.productId, Math.min(i.p.stock, i.qty + 1))}
          >
            +
          </button>
          <button className="btn2" onClick={() => set(i.productId, 0)}>
            Remove
          </button>
        </div>
      ))}
      {items.length > 0 && (
        <div className="flex justify-between items-center">
          <b className="text-xl">Total {rs(total)}</b>
          <button className="btn" onClick={() => go('#/checkout')}>
            Checkout
          </button>
        </div>
      )}
    </div>
  );
}

function Checkout({ X }: { X: any }) {
  const addrs = X.me?.user.addresses || [];
  const blank = {
    name: '',
    phone: '',
    street: '',
    city: '',
    state: '',
    pin: '',
  };
  const [sel, setSel] = useState(addrs.length ? 0 : -1);
  const [a, setA] = useState<any>(blank);
  const [save, setSave] = useState(true);
  const [m, setM] = useState('QR');
  const [ref, setRef] = useState('');
  const [qr, setQr] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    api
      .get('/api/qr')
      .then(r => setQr(r.data.url || ''))
      .catch(() => {});
  }, []);
  if (!X.me) return <Login X={X} />;
  const items = X.cart
    .map((c: any) => ({
      ...c,
      p: X.products.find((p: any) => p.id === c.productId),
    }))
    .filter((i: any) => i.p);
  const total = items.reduce((s: number, i: any) => s + i.p.price * i.qty, 0);
  if (!items.length) return <div className="box">Your cart is empty.</div>;
  const submit = () => {
    setBusy(true);
    api
      .post('/api/orders', {
        items: X.cart,
        address: sel >= 0 ? addrs[sel] : a,
        method: m,
        paymentRef: ref,
        saveAddress: sel < 0 && save,
      })
      .then(r => {
        X.setDone(r.data);
        X.setCart([]);
        X.reloadProducts();
        X.reloadMe();
        go('#/done');
      })
      .catch((e: any) => {
        X.flash(msg(e));
        setBusy(false);
      });
  };
  return (
    <div className="box space-y-4">
      <h1 className="text-2xl font-extrabold">Checkout</h1>
      <h2 className="font-extrabold">1. Delivery address</h2>
      {addrs.map((x: any, i: number) => (
        <label key={i} className="block">
          <input type="radio" checked={sel === i} onChange={() => setSel(i)} />{' '}
          {x.name}, {x.street}, {x.city}, {x.state} {x.pin}
        </label>
      ))}
      <label className="block">
        <input type="radio" checked={sel === -1} onChange={() => setSel(-1)} />{' '}
        New address
      </label>
      {sel === -1 && (
        <div className="grid grid-cols-2 gap-2">
          {Object.keys(blank).map(k => (
            <label key={k} className="block text-sm font-bold">
              {FL[k]}
              <input
                className="inp"
                placeholder={FL[k]}
                value={a[k]}
                onChange={e => setA({ ...a, [k]: e.target.value })}
              />
            </label>
          ))}
          <label className="col-span-2">
            <input
              type="checkbox"
              checked={save}
              onChange={e => setSave(e.target.checked)}
            />{' '}
            Save to my profile
          </label>
        </div>
      )}
      <h2 className="font-extrabold">2. Payment</h2>
      <label className="block">
        <input type="radio" checked={m === 'QR'} onChange={() => setM('QR')} />{' '}
        Pay by QR code
      </label>
      <label className="block">
        <input
          type="radio"
          checked={m === 'COD'}
          onChange={() => setM('COD')}
        />{' '}
        Cash on Delivery
      </label>
      {m === 'QR' && (
        <div className="text-center space-y-2">
          {qr ? (
            <img
              src={qr}
              alt="Payment QR"
              className="mx-auto w-56 rounded-2xl"
            />
          ) : (
            <p>The shop has not uploaded a QR code yet.</p>
          )}
          <div className="font-extrabold">Pay {rs(total)}</div>
          <label className="block text-sm font-bold">
            UPI / transaction reference
            <input
              className="inp"
              placeholder="UPI / transaction reference"
              value={ref}
              onChange={e => setRef(e.target.value)}
            />
          </label>
        </div>
      )}
      <div className="flex justify-between items-center">
        <b className="text-xl">Total {rs(total)}</b>
        <button className="btn" disabled={busy} onClick={submit}>
          Place order
        </button>
      </div>
    </div>
  );
}

function Done({ X }: { X: any }) {
  if (!X.done) return <div className="box">No recent order.</div>;
  return (
    <div className="box text-center space-y-2">
      <div className="text-5xl">🎉</div>
      <h1 className="text-2xl font-extrabold">Thank you!</h1>
      <p>
        Your order number is <b>{X.done.number}</b>
      </p>
      <p>
        Total {rs(X.done.total)} · Status: {X.done.status}
      </p>
      <a href="#/profile" className="btn inline-block no-underline">
        View my orders
      </a>
    </div>
  );
}

function Reviews() {
  const [rs2, setRs] = useState<any[]>([]);
  useEffect(() => {
    api
      .get('/api/reviews')
      .then(r => setRs(r.data))
      .catch(() => {});
  }, []);
  return (
    <div className="box space-y-2">
      <h1 className="text-2xl font-extrabold">💬 Recent reviews</h1>
      {rs2.length === 0 && <p>No reviews yet.</p>}
      {rs2.map(r => (
        <div key={r.id} className="border-b py-2">
          <a href={'#/p/' + r.productId}>
            <b>{r.productName}</b>
          </a>{' '}
          <span style={{ color: '#f5a623' }}>{stars(r.rating)}</span>
          <div>
            {r.comment} <i className="text-gray-500">- {r.userName}</i>
          </div>
        </div>
      ))}
    </div>
  );
}

function Profile({ X }: { X: any }) {
  const u = X.me?.user;
  const [name, setName] = useState(u?.name || '');
  const [phone, setPhone] = useState(u?.phone || '');
  const [addrs, setAddrs] = useState<any[]>(u?.addresses || []);
  const [orders, setOrders] = useState<any[]>([]);
  useEffect(() => {
    if (X.me)
      api
        .get('/api/orders')
        .then(r => setOrders(r.data))
        .catch(() => {});
  }, [X.me]);
  if (!X.me) return <Login X={X} />;
  const upd = (i: number, k: string, v: string) =>
    setAddrs(addrs.map((a, j) => (j === i ? { ...a, [k]: v } : a)));
  return (
    <div className="space-y-4">
      <div className="box space-y-2">
        <h1 className="text-2xl font-extrabold">My profile</h1>
        <div>{u.email}</div>
        <label className="block text-sm font-bold">
          Your name
          <input
            className="inp"
            placeholder="Name"
            value={name}
            onChange={e => setName(e.target.value)}
          />
        </label>
        <label className="block text-sm font-bold">
          Phone number
          <input
            className="inp"
            placeholder="Phone"
            value={phone}
            onChange={e => setPhone(e.target.value)}
          />
        </label>
        <h2 className="font-extrabold">Saved addresses</h2>
        {addrs.map((a, i) => (
          <div key={i} className="grid grid-cols-2 gap-2 border-b pb-2">
            {['name', 'phone', 'street', 'city', 'state', 'pin'].map(k => (
              <label key={k} className="block text-sm font-bold">
                {FL[k]}
                <input
                  className="inp"
                  placeholder={FL[k]}
                  value={a[k]}
                  onChange={e => upd(i, k, e.target.value)}
                />
              </label>
            ))}
            <button
              className="btn2"
              onClick={() => setAddrs(addrs.filter((_, j) => j !== i))}
            >
              Remove
            </button>
          </div>
        ))}
        {addrs.length < 5 && (
          <button
            className="btn2"
            onClick={() =>
              setAddrs([
                ...addrs,
                {
                  name: '',
                  phone: '',
                  street: '',
                  city: '',
                  state: '',
                  pin: '',
                },
              ])
            }
          >
            + Add address
          </button>
        )}
        <div>
          <button
            className="btn"
            onClick={() =>
              api
                .put('/api/me', { name, phone, addresses: addrs })
                .then(() => {
                  X.flash('Saved!');
                  X.reloadMe();
                })
                .catch((e: any) => X.flash(msg(e)))
            }
          >
            Save profile
          </button>
        </div>
      </div>
      <div className="box space-y-2">
        <h2 className="font-extrabold">Order history</h2>
        {orders.length === 0 && <p>No orders yet.</p>}
        {orders.map(o => (
          <div key={o.id} className="border-b py-2">
            <b>{o.number}</b> · {rs(o.total)} ·{' '}
            <span style={{ color: '#ff6b8b' }}>{o.status}</span>
            <div className="text-sm">
              {o.items.map((i: any) => i.name + ' x' + i.qty).join(', ')}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Admin({ X }: { X: any }) {
  const [tab, setTab] = useState('orders');
  const [orders, setOrders] = useState<any[]>([]);
  const [prods, setProds] = useState<any[]>([]);
  const [flt, setFlt] = useState('All');
  const [ed, setEd] = useState<any>(null);
  const [qr, setQr] = useState('');
  const isAdmin = !!X.me?.isAdmin;
  const load = () => {
    api
      .get('/api/admin/orders')
      .then(r => setOrders(r.data))
      .catch((e: any) => X.flash(msg(e)));
    api
      .get('/api/admin/products')
      .then(r => setProds(r.data))
      .catch(() => {});
    api
      .get('/api/qr')
      .then(r => setQr(r.data.url || ''))
      .catch(() => {});
  };
  useEffect(() => {
    if (isAdmin) load();
  }, [isAdmin]);
  if (!X.ready) return <div className="box">Loading...</div>;
  if (!X.me) return <Login X={X} />;
  if (!isAdmin)
    return (
      <div className="box text-center">
        <div className="text-4xl">🚫</div>
        <h1 className="text-xl font-extrabold">Access denied</h1>
        <p>This area is for shop admins only.</p>
      </div>
    );
  const act = (id: string, a: string) =>
    api
      .post('/api/admin/orders/' + id + '/action', { action: a })
      .then(() => {
        load();
        X.reloadProducts();
      })
      .catch((e: any) => X.flash(msg(e)));
  const pick = async (e: any, target: string) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const { data, type } = await toB64(f);
    api
      .post('/api/admin/image', { target, data, type })
      .then(() => {
        X.flash('Photo saved');
        load();
        X.reloadProducts();
      })
      .catch((er: any) => X.flash(msg(er)));
  };
  const saveP = () => {
    const call = ed.id
      ? api.put('/api/admin/products/' + ed.id, ed)
      : api.post('/api/admin/products', ed);
    call
      .then(() => {
        setEd(null);
        load();
        X.reloadProducts();
      })
      .catch((e: any) => X.flash(msg(e)));
  };
  const shown = orders.filter(o => flt === 'All' || o.status === flt);
  const statuses = [
    'All',
    'Awaiting payment verification',
    'Pending',
    'Approved',
    'Shipped',
    'Delivered',
    'Cancelled',
  ];
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-extrabold">🧶 Admin dashboard</h1>
      <div className="flex gap-2">
        {['orders', 'products', 'settings'].map(t => (
          <button
            key={t}
            className={t === tab ? 'btn' : 'btn2'}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>
      {tab === 'orders' && (
        <div className="box space-y-2">
          <label className="block text-sm font-bold">
            Filter by order status
            <select
              className="inp"
              value={flt}
              onChange={e => setFlt(e.target.value)}
            >
              {statuses.map(s => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          {shown.length === 0 && <p>No orders.</p>}
          {shown.map(o => (
            <div key={o.id} className="border-b py-2 space-y-1">
              <div>
                Order <b>{o.number}</b> · Total: {rs(o.total)} · Payment:{' '}
                {o.paymentMethod === 'QR' ? 'QR code' : 'Cash on Delivery'} ·
                Status: <b style={{ color: '#ff6b8b' }}>{o.status}</b>
              </div>
              <div className="text-sm">
                <b>Customer:</b> {o.userName} ({o.userEmail}) · <b>Phone:</b>{' '}
                {o.address.phone}
              </div>
              <div className="text-sm">
                <b>Deliver to:</b> {o.address.street}, {o.address.city},{' '}
                {o.address.state} {o.address.pin}
              </div>
              <div className="text-sm">
                <b>Items:</b>{' '}
                {o.items.map((i: any) => i.name + ' x' + i.qty).join(', ')}
              </div>
              {o.paymentMethod === 'QR' && (
                <div className="text-sm">
                  <b>UPI / transaction ref:</b> {o.paymentRef}{' '}
                  {o.paymentConfirmed ? '✅ payment confirmed' : '(not confirmed yet)'}
                </div>
              )}
              <div className="flex gap-2 flex-wrap">
                {o.paymentMethod === 'QR' &&
                  !o.paymentConfirmed &&
                  o.status !== 'Cancelled' && (
                    <button
                      className="btn2"
                      onClick={() => act(o.id, 'confirm_payment')}
                    >
                      Confirm payment
                    </button>
                  )}
                {(o.status === 'Pending' ||
                  o.status === 'Awaiting payment verification') && (
                  <button className="btn2" onClick={() => act(o.id, 'approve')}>
                    Approve
                  </button>
                )}
                {o.status === 'Approved' && (
                  <button className="btn2" onClick={() => act(o.id, 'ship')}>
                    Mark shipped
                  </button>
                )}
                {o.status === 'Shipped' && (
                  <button className="btn2" onClick={() => act(o.id, 'deliver')}>
                    Mark delivered
                  </button>
                )}
                {o.status !== 'Cancelled' && o.status !== 'Delivered' && (
                  <button
                    className="btn2"
                    onClick={() =>
                      window.confirm(
                        'Cancel this order and return items to stock?'
                      ) && act(o.id, 'cancel')
                    }
                  >
                    Cancel
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
      {tab === 'products' && (
        <div className="box space-y-2">
          <button
            className="btn"
            onClick={() =>
              setEd({
                name: '',
                description: '',
                price: 0,
                stock: 5,
                category: CATS[0],
                hidden: false,
              })
            }
          >
            + Add product
          </button>
          {ed && (
            <div className="space-y-2 border-2 border-pink-100 rounded-2xl p-3">
              <label className="block text-sm font-bold">
                Product name
                <input
                  className="inp"
                  placeholder="Name"
                  value={ed.name}
                  onChange={e => setEd({ ...ed, name: e.target.value })}
                />
              </label>
              <label className="block text-sm font-bold">
                Description
                <input
                  className="inp"
                  placeholder="Description"
                  value={ed.description}
                  onChange={e => setEd({ ...ed, description: e.target.value })}
                />
              </label>
              <div className="grid grid-cols-3 gap-2">
                <label className="block text-sm font-bold">
                  Price (₹)
                  <input
                    className="inp"
                    type="number"
                    placeholder="Price"
                    value={ed.price}
                    onChange={e => setEd({ ...ed, price: e.target.value })}
                  />
                </label>
                <label className="block text-sm font-bold">
                  Stock quantity
                  <input
                    className="inp"
                    type="number"
                    placeholder="Stock"
                    value={ed.stock}
                    onChange={e => setEd({ ...ed, stock: e.target.value })}
                  />
                </label>
                <label className="block text-sm font-bold">
                  Category
                  <select
                    className="inp"
                    value={ed.category}
                    onChange={e => setEd({ ...ed, category: e.target.value })}
                  >
                    {CATS.map(c => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </label>
              </div>
              <label>
                <input
                  type="checkbox"
                  checked={!!ed.hidden}
                  onChange={e => setEd({ ...ed, hidden: e.target.checked })}
                />{' '}
                Hidden
              </label>
              <div className="flex gap-2">
                <button className="btn" onClick={saveP}>
                  Save
                </button>
                <button className="btn2" onClick={() => setEd(null)}>
                  Close
                </button>
              </div>
            </div>
          )}
          {prods.map(p => (
            <div
              key={p.id}
              className="flex items-center gap-2 border-b py-2 flex-wrap"
              style={
                p.stock <= 2
                  ? { background: '#fff3cd', borderRadius: 12, padding: 6 }
                  : {}
              }
            >
              <div className="w-12 h-12 rounded-xl overflow-hidden">
                <Img p={p} />
              </div>
              <div className="flex-1 min-w-32">
                <b>{p.name}</b>
                {p.hidden ? ' (hidden)' : ''}
                <div className="text-sm">
                  Category: {p.category} · Price: {rs(p.price)} · Stock:{' '}
                  {p.stock}
                  {p.stock <= 2 ? ' ⚠️ low' : ''}
                </div>
              </div>
              <label className="btn2 text-sm">
                Photo
                <input
                  type="file"
                  accept="image/*"
                  hidden
                  onChange={e => pick(e, p.id)}
                />
              </label>
              {(p.imageUrl || (!p.noPhoto && photosOf(p.name).length > 0)) && (
                <button
                  className="btn2"
                  onClick={() =>
                    window.confirm('Remove the photo from ' + p.name + '?') &&
                    api
                      .delete('/api/admin/products/' + p.id + '/image')
                      .then(() => {
                        X.flash('Photo removed');
                        load();
                        X.reloadProducts();
                      })
                      .catch((e: any) => X.flash(msg(e)))
                  }
                >
                  Remove photo
                </button>
              )}
              <button className="btn2" onClick={() => setEd({ ...p })}>
                Edit
              </button>
              <button
                className="btn2"
                onClick={() =>
                  api
                    .put('/api/admin/products/' + p.id, {
                      ...p,
                      hidden: !p.hidden,
                    })
                    .then(() => {
                      load();
                      X.reloadProducts();
                    })
                    .catch((e: any) => X.flash(msg(e)))
                }
              >
                {p.hidden ? 'Show' : 'Hide'}
              </button>
              <button
                className="btn2"
                onClick={() =>
                  window.confirm('Delete ' + p.name + '?') &&
                  api
                    .delete('/api/admin/products/' + p.id)
                    .then(() => {
                      load();
                      X.reloadProducts();
                    })
                    .catch((e: any) => X.flash(msg(e)))
                }
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      )}
      {tab === 'settings' && (
        <div className="box space-y-2">
          <h2 className="font-extrabold">Payment QR code</h2>
          {qr ? (
            <img src={qr} alt="QR" className="w-48 rounded-2xl" />
          ) : (
            <p>No QR uploaded yet.</p>
          )}
          <label className="btn inline-block">
            Upload / replace QR
            <input
              type="file"
              accept="image/*"
              hidden
              onChange={e => pick(e, 'qr')}
            />
          </label>
        </div>
      )}
    </div>
  );
}

export default function Mittens() {
  const [route, setRoute] = useState(location.hash || '#/');
  const [me, setMe] = useState<any>(null);
  const [ready, setReady] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [cart, setCart] = useState<any[]>([]);
  const [done, setDone] = useState<any>(null);
  const [toast, setToast] = useState('');
  useEffect(() => {
    const f = () => {
      setRoute(location.hash || '#/');
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  const flash = (t: string) => {
    setToast(t);
    setTimeout(() => setToast(''), 3000);
  };
  const reloadProducts = () =>
    api
      .get('/api/products')
      .then(r => setProducts(r.data))
      .catch(() => {});
  const reloadMe = () =>
    api
      .get('/api/me')
      .then(r => {
        setMe(r.data);
        setCart(r.data.user.cart || []);
      })
      .catch(() => {});
  useEffect(() => {
    (async () => {
      try {
        await reloadProducts();
        const u = await auth.getUser();
        if (u) await reloadMe();
      } catch (e) {
        /* signed out */
      }
      setReady(true);
    })();
  }, []);
  const signIn = () => {
    auth
      .signInWithRedirect()
      .catch(() => flash('Sign-in failed, please try again'));
  };
  const saveCart = (next: any[]) => {
    const clean = next.map(c => ({ productId: c.productId, qty: c.qty }));
    setCart(clean);
    api.put('/api/me', { cart: clean }).catch(() => {});
  };
  const addToCart = (id: string, qty: number) => {
    if (!me) {
      signIn();
      return;
    }
    const ex = cart.find(c => c.productId === id);
    saveCart(
      ex
        ? cart.map(c => (c.productId === id ? { ...c, qty: c.qty + qty } : c))
        : [...cart, { productId: id, qty }]
    );
    flash('Added to cart 🧶');
  };
  const X = {
    me,
    ready,
    products,
    cart,
    setCart,
    saveCart,
    addToCart,
    done,
    setDone,
    flash,
    signIn,
    reloadProducts,
    reloadMe,
  };
  const r = route.replace(/^#/, '') || '/';
  let page: any = <Home X={X} />;
  if (r.startsWith('/p/')) page = <Product X={X} id={r.slice(3)} key={r} />;
  else if (r === '/foryou') page = <ForYou X={X} />;
  else if (r === '/cart') page = <CartPage X={X} />;
  else if (r === '/checkout') page = <Checkout X={X} />;
  else if (r === '/done') page = <Done X={X} />;
  else if (r === '/reviews') page = <Reviews />;
  else if (r === '/profile') page = <Profile X={X} />;
  else if (r === '/admin') page = <Admin X={X} />;
  const n = cart.reduce((s, c) => s + c.qty, 0);
  return (
    <div className="max-w-5xl mx-auto p-3">
      <header className="flex items-center justify-between flex-wrap gap-2 mb-4">
        <a
          href="#/"
          className="logo text-4xl no-underline"
          style={{ color: '#ff6b8b' }}
        >
          🧶 Mittens
        </a>
        <nav className="nav flex gap-4 flex-wrap items-center">
          <a href="#/">Home</a>
          <a href="#/foryou">For You</a>
          <a href="#/reviews">Reviews</a>
          <a href="#/cart">Cart ({n})</a>
          <a href="#/profile">Profile</a>
          {me?.isAdmin && <a href="#/admin">Admin</a>}
          {me ? (
            <button
              className="btn2"
              onClick={() =>
                auth.signOut().then(() => {
                  setMe(null);
                  setCart([]);
                  go('#/');
                })
              }
            >
              Sign out
            </button>
          ) : (
            <button className="btn" onClick={signIn}>
              Sign in
            </button>
          )}
        </nav>
      </header>
      {ready ? page : <div className="box">Loading...</div>}
      {toast && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-white border-2 border-pink-300 rounded-full px-5 py-2 shadow-lg font-bold">
          {toast}
        </div>
      )}
    </div>
  );
}
